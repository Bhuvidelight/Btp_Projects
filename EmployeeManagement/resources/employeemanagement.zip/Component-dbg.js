sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("employeemanagement.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);